
# Urban-Company Clone
Urban company is an online webapp to get expert local services such as 
repair services, grooming services etc...
The company has separate app for mobile users and our cloned version is 
for laptop and tablet users.

The cloned version is responsive as well.






## Authors

- [@HemanthKumar-CN](https://github.com/HemanthKumar-CN)
- [@Suraj Dongre](https://github.com/surajDongre-16)
- [@Shreenath Panchal](https://github.com/Aknathpanchal)
- [@Rohit Kumar](https://github.com/rk6093720)



## Screenshots

- Home Page

![App Screenshot](https://i.ibb.co/Mf7PwLp/uc.png)


## Features

- Mobile OTP Login
- Select your City
- Bookings History


## Tech Stacks Used:

- React
- Redux
- Chakra UI
- Firebase




