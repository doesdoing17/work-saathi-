// import React from "react";
// import "./new.css"

// function new1() {
//   return (
//     <div>
//       <div
//         className="cardContainer"
//         data-index="2"
//         data-key="packageList/0/skuCard/0"
//       >
        
//                                           >
//                           ₹849{" "}
//                         </div>
//                       </div>
//                       <div className="css-1dbjc4n r-1hvjb8t">
//                         <div
//                           dir="auto"
//                           className="css-901oao css-cens5h r-ogrl0h r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-fdjqy7 r-3twk1y"
//                           style="-webkit-line-clamp: 1; text-decoration-line: line-through;"
//                         >
//                           ₹899{" "}
//                         </div>
//                       </div>
//                       <div className="css-1dbjc4n r-1awozwy r-18u37iz r-1777fci">
//                         <div className="css-1dbjc4n r-1hvjb8t">
//                           <div
//                             aria-disabled="true"
//                             role="img"
//                             tabIndex="-1"
//                             className="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-10ptun7 r-1udh08x r-1i6wzkk r-lrvibr r-1janqcz"
//                             style="transition-duration: 0s;"
//                           >
//                             <div
//                               tabIndex="-1"
//                               className="css-1dbjc4n r-13awgt0 r-15651gt"
//                             >
//                               <svg
//                                 width="100%"
//                                 height="100%"
//                                 viewBox="0 0 24 24"
//                                 fill="#545454"
//                                 xmlns="http://www.w3.org/2000/svg"
//                               >
//                                 <path
//                                   d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
//                                   fill="#545454"
//                                 ></path>
//                               </svg>
//                             </div>
//                           </div>
//                         </div>
//                         <div
//                           dir="auto"
//                           className="css-901oao css-cens5h r-ogrl0h r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-fdjqy7 r-13wfysu r-3twk1y"
//                           style="-webkit-line-clamp: 1;"
//                         >
//                           1 hr 5 mins
//                         </div>
//                       </div>
//                     </div>
//                     <div
//                       className="css-1dbjc4n r-3da1kt r-1jg9483"
//                       data-testid="space"
//                     ></div>





// {/*                     
//                     <div className="css-1dbjc4n r-18u37iz">
//                       <div className="css-1dbjc4n r-1awozwy r-z80fyv r-1pyaxff r-14eup4l">
//                         <div
//                           aria-disabled="true"
//                           role="img"
//                           tabIndex="-1"
//                           className="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-tbmifm r-1udh08x r-1i6wzkk r-lrvibr r-16eto9q"
//                           style="transition-duration: 0s;"
//                         >
//                           <div
//                             tabIndex="-1"
//                             className="css-1dbjc4n r-13awgt0 r-15651gt"
//                           >
//                             <svg
//                               width="100%"
//                               height="100%"
//                               viewBox="0 0 16 16"
//                               fill="#07794C"
//                               xmlns="http://www.w3.org/2000/svg"
//                             >
//                               <path
//                                 d="M15 7.929L8.472 1.4a.997.997 0 00-.904-.274l-5.04 1.008a.5.5 0 00-.393.393l-1.008 5.04a.998.998 0 00.274.904L7.928 15a.999.999 0 001.414 0L15 9.343a.999.999 0 000-1.414zM5.25 6a.75.75 0 110-1.5.75.75 0 010 1.5z"
//                                 fill="#07794C"
//                               ></path>
//                             </svg>
//                           </div>
//                         </div>
//                       </div>
//                       <div
//                         dir="auto"
//                         className="css-901oao css-cens5h r-ogrl0h r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-fdjqy7 r-13wfysu r-3twk1y"
//                         style="-webkit-line-clamp: 2;"
//                       >
//                         ₹50 off above ₹499
//                       </div>
//                     </div> */}
//                   </div>
//                   <div className="css-1dbjc4n r-13qz1uu">
//                     <div
//                       aria-label="Bullet list defining packages"
//                       tabIndex="-1"
//                       className="css-1dbjc4n r-13qz1uu"
//                     >
//                       <div
//                         className="css-1dbjc4n r-tbmifm r-16eto9q"
//                         data-testid="space"
//                       ></div>
//                       <div
//                         className="css-1dbjc4n r-13qz1uu"
//                         style="align-self: center; background-color: rgb(176, 176, 176); height: 1px;"
//                       ></div>
//                       <div
//                         className="css-1dbjc4n r-3da1kt r-1jg9483"
//                         data-testid="space"
//                       ></div>
//                       <div className="css-1dbjc4n r-mk0yit r-rjfia r-13qz1uu">
//                         {/* <div className="css-1dbjc4n r-18u37iz r-15zivkp">
//                           <div className="css-1dbjc4n r-1awozwy r-10ptun7 r-1777fci r-1qortcd">
//                             <div
//                               aria-disabled="true"
//                               role="img"
//                               tabIndex="-1"
//                               className="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-10ptun7 r-1udh08x r-1i6wzkk r-lrvibr r-1janqcz"
//                               style="transition-duration: 0s;"
//                             >
//                               <div
//                                 tabIndex="-1"
//                                 className="css-1dbjc4n r-13awgt0 r-15651gt"
//                               >
//                                 <svg
//                                   width="100%"
//                                   height="100%"
//                                   viewBox="0 0 24 24"
//                                   fill="#545454"
//                                   xmlns="http://www.w3.org/2000/svg"
//                                 >
//                                   <path
//                                     d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
//                                     fill="#545454"
//                                   ></path>
//                                 </svg>
//                               </div>
//                             </div>
//                           </div>
//                           <div className="css-1dbjc4n r-1habvwh r-1iusvr4 r-16y2uox r-1wbh5a2">
//                             <div
//                               dir="auto"
//                               className="css-901oao css-cens5h r-ogrl0h r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-fdjqy7 r-13wfysu r-3twk1y"
//                               style="-webkit-line-clamp: 2;"
//                             >
//                               Eyebrow threading
//                             </div>
//                           </div>
//                         </div> */}
//                         {/* <div className="css-1dbjc4n r-18u37iz r-15zivkp">
//                           <div className="css-1dbjc4n r-1awozwy r-10ptun7 r-1777fci r-1qortcd">
//                             <div
//                               aria-disabled="true"
//                               role="img"
//                               tabIndex="-1"
//                               className="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-10ptun7 r-1udh08x r-1i6wzkk r-lrvibr r-1janqcz"
//                               style="transition-duration: 0s;"
//                             >
//                               <div
//                                 tabIndex="-1"
//                                 className="css-1dbjc4n r-13awgt0 r-15651gt"
//                               >
//                                 <svg
//                                   width="100%"
//                                   height="100%"
//                                   viewBox="0 0 24 24"
//                                   fill="#545454"
//                                   xmlns="http://www.w3.org/2000/svg"
//                                 >
//                                   <path
//                                     d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
//                                     fill="#545454"
//                                   ></path>
//                                 </svg>
//                               </div>
//                             </div>
//                           </div>
//                           <div className="css-1dbjc4n r-1habvwh r-1iusvr4 r-16y2uox r-1wbh5a2">
//                             <div
//                               dir="auto"
//                               className="css-901oao css-cens5h r-ogrl0h r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-fdjqy7 r-13wfysu r-3twk1y"
//                               style="-webkit-line-clamp: 2;"
//                             >
//                               Upper lip threading{" "}
//                             </div>
//                           </div>
//                         </div> */}
//                         {/* <div className="css-1dbjc4n r-18u37iz r-p1pxzi">
//                           <div className="css-1dbjc4n r-1awozwy r-10ptun7 r-1777fci r-1qortcd">
//                             <div 
//                               aria-disabled="true"
//                               role="img"
//                               tabIndex="-1"
//                               className="css-1dbjc4n r-1xc7w19 r-1xfd6ze r-1phboty r-1yadl64 r-10ptun7 r-1udh08x r-1i6wzkk r-lrvibr r-1janqcz"
//                               style="transition-duration: 0s;"
//                             >
//                               <div
//                                 tabIndex="-1"
//                                 className="css-1dbjc4n r-13awgt0 r-15651gt"
//                               >
//                                 <svg
//                                   width="100%"
//                                   height="100%"
//                                   viewBox="0 0 24 24"
//                                   fill="#545454"
//                                   xmlns="http://www.w3.org/2000/svg"
//                                 >
//                                   <path
//                                     d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
//                                     fill="#545454"
//                                   ></path>
//                                 </svg>
//                               </div>
//                             </div>
//                           </div>
//                           <div className="css-1dbjc4n r-1habvwh r-1iusvr4 r-16y2uox r-1wbh5a2">
//                             <div
//                               dir="auto"
//                               className="css-901oao css-cens5h r-ogrl0h r-1ej5qbt r-1enofrn r-16dba41 r-1cwl3u0 r-fdjqy7 r-13wfysu r-3twk1y"
//                               style="-webkit-line-clamp: 2;"
//                             >
//                               Chocolate full arms, underarms, full legs
//                             </div>
//                           </div>
//                         </div> */}
//                       </div>
//                     </div>
//                     <div
//                       className="css-1dbjc4n r-10ptun7 r-1janqcz"
//                       data-testid="space"
//                     ></div>
//                     {/* <div className="css-1dbjc4n r-1habvwh r-13qz1uu">
//                       <div
//                         aria-label="Button Double Tap to perform action"
//                         role="button"
//                         tabIndex="0"
//                         className="css-18t94o4 css-1dbjc4n r-1loqt21 r-1otgn73 r-1i6wzkk r-lrvibr"
//                         data-testid="defaultButton"
//                         style="transition-duration: 0s;"
//                       >
//                         <div className="css-1dbjc4n r-1awozwy r-14lw9ot r-wh77r2 r-1xfd6ze r-1phboty r-rs99b7 r-18u37iz r-1r8g8re r-1777fci r-ymttw5 r-1rcbeiy r-iyfy8q">
//                           <div className="css-1dbjc4n r-1awozwy r-18u37iz">
//                             <div
//                               className="css-1dbjc4n"
//                               data-testid="TextContainer"
//                               style="opacity: 1;"
//                             >
//                               <div
//                                 dir="auto"
//                                 className="css-901oao css-cens5h r-144iecu r-1b43r93 r-1kfrs79 r-13wfysu r-3twk1y"
//                                 style="-webkit-line-clamp: 1; color: rgb(15, 15, 15); line-height: 20px; text-align: center;"
//                               >
//                                 Edit your package
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div> */}
//                   </div>
//                 </div>
//                 <div className="css-1dbjc4n r-1awozwy r-puj83k r-1h8ys4a">
//                   <div className="css-1dbjc4n r-1wzrnnt r-1pn2ns4">
//                     <div className="css-1dbjc4n r-1awozwy r-1glkqn6">
//                       <div
//                         role="button"
//                         tabIndex="0"
//                         className="css-18t94o4 css-1dbjc4n r-1awozwy r-14lw9ot r-aci1zz r-1xfd6ze r-1phboty r-rs99b7 r-1loqt21 r-mabqd8 r-1777fci r-1otgn73 r-1i6wzkk r-lrvibr r-1glkqn6"
//                         style="box-shadow: rgba(0, 0, 0, 0) 0px 0px 0px; transition-duration: 0s;"
//                       >
//                         <div className="css-1dbjc4n r-633pao">
//                           <div
//                             dir="auto"
//                             className="css-901oao r-144iecu r-1b43r93 r-1kfrs79 r-fdjqy7 r-13wfysu r-3twk1y"
//                             style="color: rgb(110, 66, 229); line-height: 20px;"
//                           >
//                             Add
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//               <div
//                 className="css-1dbjc4n r-mabqd8 r-1yvhtrz"
//                 data-testid="space"
//               ></div>
//               <div
//                 className="css-1dbjc4n r-13qz1uu"
//                 style="align-self: center; background-color: rgb(227, 227, 227); height: 1px;"
//               ></div>
//             </div>
//           </div>
//           <div className="css-1dbjc4n"></div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default new1;
